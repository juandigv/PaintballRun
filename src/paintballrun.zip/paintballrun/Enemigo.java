package paintballrun;

import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class Enemigo extends Circle {
	private Random r;
	private Bala bala;
	private double x, y;

	public Enemigo() {

		super();
		r = new Random();

		this.setCenterX(r.nextInt(380) + 30);
		this.setCenterY(r.nextInt(300) + 120);
		this.setRadius(15);

	}

	public void crearBala(Pane paneCancha, ArrayList<Bala> balaCancha) throws MalformedURLException {
		bala = new Bala(this.getCenterX(), this.getCenterY());
		File file = new File("resources/bala.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);
		bala.setFill(new ImagePattern(img));
		paneCancha.getChildren().add(bala);
		balaCancha.add(bala);
		System.out.println("adding bala at " + this.getCenterX() + " " + this.getCenterY() );
		System.out.println(balaCancha.size());
	}

	public void calcularAngulo(double posx, double posy) {
		x = posx;
		y = posy;
		int angulo = (int) (Math.toDegrees(Math.atan2((posy - this.getCenterY()), (posx - this.getCenterX()))));
		if (bala.getCenterX() == this.getCenterX() || bala.getCenterX() == this.getCenterX())
			bala.setAngulo(angulo);
	}

	public boolean impacto() {

		if (bala.getCenterX() > 500 || bala.getCenterX() < 0) {
			return true;
		}
		
		if (bala.getCenterX() < x + 20 && bala.getCenterX() > x - 20 && bala.getCenterY() < y + 20
				&& bala.getCenterY() > y - 20) {
			return true;
		}
		
		if (bala.getCenterY() > 500 || bala.getCenterY() < 0) {
			return true;
		}

		else {
			return false;
		}
	}

	public boolean impactojugador() {
		if (bala.getCenterX() < x + 10 && bala.getCenterX() > x - 10 && bala.getCenterY() < y + 10
				&& bala.getCenterY() > y - 10) {
			return true;
		}
		return false;
	}

	public void disparar() {
		if (impacto()) {
			bala.setCenterX(this.getCenterX());
			bala.setCenterY(this.getCenterY());
		} else {
			bala.mover();
		}
	}
}
