package paintballrun;

import java.util.ArrayList;
import java.util.Date;

import javafx.animation.AnimationTimer;

public class AnimationTimerBala extends AnimationTimer {
	
	private EquipoEnemigo misEnemigos;
	private Jugador miJugador;
	private ArrayList<Bala> balaCancha;
	private int vidas = 3;
	
	public AnimationTimerBala(EquipoEnemigo misEnemigos, Jugador miJugador, ArrayList<Bala> balaCancha) {
		this.misEnemigos=misEnemigos;
		this.miJugador=miJugador;
		this.balaCancha = balaCancha;
	}

	@Override
	public void handle(long arg0) {
		if(vidas > 0) {
			misEnemigos.disparar();
			misEnemigos.angulotiempo(miJugador.getCenterX(),miJugador.getCenterY());
			//Date date = new Date();
			//System.out.println(date.getTime()); 
			if(impactoJugadorBala()) {
				vidas--;
			}
		} else {
			System.out.println("YOU LOST");
		}
	}
	
	public boolean impactoJugadorBala() {
		long distanciaX;
		long distanciaY;
		boolean impacto = false;
		
		for (int i = 0; i < balaCancha.size(); i++) {
			distanciaX = Math.abs(Math.round(balaCancha.get(i).getCenterX() - miJugador.getCenterX()));
			distanciaY = Math.abs(Math.round(balaCancha.get(i).getCenterY() - miJugador.getCenterY()));

			if(distanciaX < 20 && distanciaY < 20) {
				System.out.println("Player hit");

				impacto = true;
			}
		}
		return impacto;
	}
	
}


