package paintballrun;

import javafx.scene.layout.Pane;
import java.io.File;
import java.net.MalformedURLException;
import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;

public class EquipoEnemigo {

	private Enemigo enemigos[];

	public EquipoEnemigo(int n) throws MalformedURLException {
		enemigos = new Enemigo[n];
		File file = new File("resources/enemy.png");
		String localUrl = file.toURI().toURL().toString();
		Image img = new Image(localUrl);
		
		for (int i = 0; i < enemigos.length; i++) {
			enemigos[i] = new Enemigo();
			enemigos[i].setFill(new ImagePattern(img));
		}
	}

	public void addPanel(Pane paneCancha, ArrayList<Bala> balaCancha) throws MalformedURLException {
		for (int i = 0; i < enemigos.length; i++) {
			paneCancha.getChildren().add(enemigos[i]);
			enemigos[i].crearBala(paneCancha, balaCancha);
		}
	}

	public void disparar() {

		for (int i = 0; i < enemigos.length; i++) {
			enemigos[i].disparar();
		}
	}

	public void angulotiempo(double posx, double posy) {
		for (int i = 0; i < enemigos.length; i++) {
			enemigos[i].calcularAngulo(posx, posy);
		}
	}

}
