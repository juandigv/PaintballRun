package paintballrun;

import java.io.File;
import java.net.MalformedURLException;
import java.time.Duration;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.input.KeyEvent;

public class PaintBallRunController {

	@FXML
	private Pane paneCancha;

	private AnimationTimerBala miTimer;
	private Jugador miJugador;
	private EquipoEnemigo misEnemigos;
	private BanderaEnemiga bandera;
	private MediaPlayer mediaPlayerSteps;
	private ArrayList<Bala> balaCancha;

	public PaintBallRunController() {
		System.out.println("Constructor de PaintBalRun");
		balaCancha = new ArrayList<Bala>();
	}

	@FXML
	public void initialize() throws MalformedURLException {
		Rectangle clip = new Rectangle(0, 0, 0, 0);
		clip.widthProperty().bind(paneCancha.widthProperty());
		clip.heightProperty().bind(paneCancha.heightProperty());

		paneCancha.setClip(clip);

		miJugador = new Jugador();
		misEnemigos = new EquipoEnemigo(5);
		misEnemigos.addPanel(paneCancha, balaCancha);
		bandera = new BanderaEnemiga();
		
		
		
		File fileMusic = new File("resources/bg1.mp3");
		String localUrlMusic = fileMusic.toURI().toURL().toString();
		Media media = new Media(localUrlMusic);
		MediaPlayer mediaPlayer = new MediaPlayer(media);
		mediaPlayer.setVolume(10);
		mediaPlayer.play();
		File fileSteps = new File("resources/steps.mp3");
		String localUrlSteps = fileSteps.toURI().toURL().toString();
		Media steps = new Media(localUrlSteps);
		mediaPlayerSteps = new MediaPlayer(steps);
		mediaPlayerSteps.play();
		
		File fileP = new File("resources/player.png");
		String localUrlP = fileP.toURI().toURL().toString();
		Image imgplayer = new Image(localUrlP);
		miJugador.setFill(new ImagePattern(imgplayer));
		File fileB = new File("resources/bandera.png");
		String localUrlB = fileB.toURI().toURL().toString();
		Image imgbandera = new Image(localUrlB);
		bandera.setFill(new ImagePattern(imgbandera));

		paneCancha.getChildren().addAll(bandera, miJugador);
		miTimer = new AnimationTimerBala(misEnemigos, miJugador, balaCancha);
		miTimer.start();

	}

	@FXML
	public void keyMoveHnd(KeyEvent key) {
		double x = miJugador.getCenterX();
		double y = miJugador.getCenterY();

		switch (key.getCode()) {
		case UP:
		case KP_UP:
		case I:
			if (y >= 20)
				mediaPlayerSteps.play();
			y -= 3;
			break;
		case DOWN:
		case KP_DOWN:
		case K:
			if (y <= 480)
				mediaPlayerSteps.play();
			y += 3;
			break;
		case LEFT:
		case KP_LEFT:
		case J:
			if (x >= 20)
				mediaPlayerSteps.play();
			x -= 3;
			break;
		case RIGHT:
		case KP_RIGHT:
		case L:
			if (x < 430)
				mediaPlayerSteps.play();
			x += 3;
			break;
		default:
			System.out.println("KeyMoveHnd:" + key.getCode());
			break;
		}

		key.consume();

		miJugador.setCenterX(x);
		miJugador.setCenterY(y);
	}

}
