package paintballrun;

import java.util.Random;
import javafx.scene.shape.Circle;

public class Jugador extends Circle {
	private Random r;
	private Enemigo enemigo;

	public Jugador() {

		super();
		r = new Random();

		this.setCenterX(r.nextInt(380) + 30);
		this.setCenterY(475);
		this.setRadius(15);

	}

	public void dead() {
		if (enemigo.impactojugador()) {
			System.out.println("c murio"+enemigo.impactojugador());
			this.setCenterX(r.nextInt(380) + 30);
			this.setCenterY(475);
		}
	}



}
